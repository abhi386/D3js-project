import * as d3 from 'd3';
//import $ from 'jquery';
import 'bootstrap';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'webpack-icons-installer/bootstrap';
import './css/style.css';


const chart = d3.select('body') //this selects the HTML <body>
  .append('svg') //appends svg element
  .attr('id', 'chart'); //gives it an ID of #chart


/*The following code below initiates object XMLHttpRequest
tells it to load data and passess it to function mungeData once it is loaded
 NOTE
   adding 'const' in front of variable (req) would prevent variable from being reassigned
  although it can be modified. Suggestion: use 'let' if you are going to reassign variable.
*/
  const req = new window.XMLHttpRequest(); 
  req.addEventListener('load', mungeData);
  req.open('GET', 'data/EUdata.csv');
  req.send();

/* Call mungeData function to parse CSV data string in an object.
Data transformed in 3 steps.
1. we converted it into an array of objects using d3.csvParse() and assign the result to data.
2. Then we transform the array into an object keyed by the region, such that the object's
keys are the regions, and the values are an array of associated constituencies.
3. Lastly Object.entries converts an object into a multidimensional array consisting of elements
comprising of key-valu pairs, which we can then reduce into a new object comprising of
each constituencis voter turnout percentage 
*/
  function mungeData() {
    const data = d3.csvParse(this.responseText);
    const regions = data.reduce((last, row) => {
      if (!last[row.Region]) last[row.Region] = [];
      last[row.Region].push(row);
      return last;
    }, {});
    const regionsPctTurnout = Object.entries(regions)
      .map(([region, areas]) => ({
        region,
        meanPctTurnout: d3.mean(areas, d => d.Pct_Turnout),
      }));
   
  /*renderChart function takes the chart variable and sets its width and height 
  to that of the window */    
  renderChart(regionsPctTurnout);
  }
  function renderChart(data) {
    chart.attr('width', window.innerWidth)
      .attr('height', window.innerHeight);
 /*The x scale is now a function that maps inputs from a domain composed of our 
 region names to a range of values between 50 and the width of your viewport 
 (minus 50), with some spacing defined by the 0.1 value given to .padding() . 
  */
  const x = d3.scaleBand()
    .domain(data.map(d => d.region))
    .rangeRound([50, window.innerWidth - 50])
    .padding(0.1);
/*Similarly, the y scale is going to map a linear domain (which runs from zero 
  to the max value of our data, the latter of which we acquire using d3.max ) to 
  a range between window.innerHeight (minus our 50 pixel margin) and 0 . Inverting 
  the range is important because D3 considers the top of a graph to be y=0 */
  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.meanPctTurnout)])
    .range([window.innerHeight - 50, 0]);

//Now we define our axes.    
  const xAxis = d3.axisBottom().scale(x);
  const yAxis = d3.axisLeft().scale(y);

// Now we will draw axes on our graph  
  chart.append('g')
    .attr('class', 'axis')
    .attr('transform', `translate(0, ${window.innerHeight - 50})`)
    .call(xAxis);

  chart.append('g')
     .attr('class', 'axis')
     .attr('transform', 'translate(50, 0)')
     .call(yAxis);

/* The code below does the following
  - For all rectangles(rect) in the graph, load our data
  - Go through it
  - For each item, append a rect
  - Then, define some attributes to it */     
chart.selectAll('rect')
 .data(data)
 .enter() 
 .append('rect') 
 .attr('class', 'bar') 
 .attr('x', d => x(d.region)) // calculate the horizontal positiom
 .attr('y',window.innerHeight-50) //sets all bars at the bottom 
 //.attr('y', d => y(d.meanPctTurnout)) //calculates the vertical position
 .attr('width', x.bandwidth()) // gives the width of the bar
 .attr('height',0) // with height zero
 .transition() // set up animation
 .delay((d,i)=> i*20) // each bar delayed by 20 milliseconds
 .duration(800) // each animation last for about 1 second (0.8 sec)
 .attr('y',d => y(d.meanPctTurnout))
 .attr('height', d =>
     (window.innerHeight - 50) - y(d.meanPctTurnout)); //calculates height from y to bottom
}
/*Note that whenever we needed a different value for every element, we defined an attribute 
as a function ( x , y , and height ); otherwise, we defined it as a value ( width ). */



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
$(window).on("load", () => {



  // D3 sample code to draw circles 
 var svgContainer = d3.select("body").append("svg")
    .attr("width", 1000)
    .attr("height", 1000);
  

  console.log("hello");

  var data = [32, 57, 293, 900];

  d3.select("svg").selectAll("circle")
      .data(data)
    .enter().append("circle")
    .attr("cy", 90)
    .attr("cx", String)
    .attr("r", Math.sqrt);



});
*/